# CHIP Makefile Style Guide

Use `tabs` only where strictly necessary. For example, Avoid using `tabs` to
align line breaks.
