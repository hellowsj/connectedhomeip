# Python framework tests

This file is a placeholder for python framework test information.

NOTE: be sure to include information about how you need to commission with the
python controller, not chip-tool and how to do that in the scripts
