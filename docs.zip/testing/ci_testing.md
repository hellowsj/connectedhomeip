# CI testing

This file is a placeholder for information on how to run tests in the CI.

NOTE: discuss in particular triggers direct to the device, test event triggers
and the CI pics.
