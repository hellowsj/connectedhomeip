# PICS and PIXITs

Placeholder file for PICS and PIXIT info

-   PICS formats - XML vs. test harness
-   PICS in CI
-   PICS tool and how we practically use it in Matter
-   PICS checker test
-   PIXITs in tests and how to set them
-   Why you should avoid using both of these things.
