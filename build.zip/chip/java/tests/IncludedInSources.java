package build.chip.java.tests;

public class IncludedInSources {
  IncludedInChildSources includedInChildSources;
  IncludedInChildSources2 includedInChildSources2;
  IncludedInGrandchildSources includedInGrandchildSources;

  IncludedInJar includedInJar;
}
