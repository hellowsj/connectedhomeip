package build.chip.java.tests;

public class IncludedInJar {
  IncludedInChildJar includedInChildJar;
}
