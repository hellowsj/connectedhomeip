package build.chip.java.tests;

public class IncludedInChildSources2 {
  IncludedInGrandchildSources includedInGrandchildSources;
}
